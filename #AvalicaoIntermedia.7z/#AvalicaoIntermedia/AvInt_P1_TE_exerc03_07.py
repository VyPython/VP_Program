
# vii. Exemplo de NameError:

try:
    print(nome)
except NameError:

    print("Erro: Variável não definida.")


