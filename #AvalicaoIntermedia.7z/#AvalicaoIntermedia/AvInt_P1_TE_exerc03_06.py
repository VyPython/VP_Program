
# vi. Exemplo de TypeError:

try:
    soma = "10" + 5
except TypeError:
    
    print("Erro: Operação inválida entre tipos diferentes.")

