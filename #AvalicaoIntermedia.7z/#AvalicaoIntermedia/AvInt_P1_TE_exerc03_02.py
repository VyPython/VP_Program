
# ii. Exemplo de  ZeroDivisionError:

try:
    resultado = 10 / 0
except ZeroDivisionError:
    print ("Erro: Não é possível a divisão por zero.")
